document.querySelector('.login .btn').onclick=()=>{
    document.querySelector('.login').classList.add('was-validated');
}