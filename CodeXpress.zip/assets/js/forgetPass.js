document.querySelector('.send-forgot-email .btn').onclick=()=>{
    document.querySelector('.send-forgot-email').classList.add('was-validated');
}