1. Add timeDelta.js file to your project
2. call the function

timeDelta(timestamp1); // elapsed/remained time from timestamp1 until now
// or
timeDelta(timestamp1, timestamp2); // elapsed/remained time from timestamp1 until timestamp2 

see example.html file for more details

Note: the params should be acceptable for Date() constractor